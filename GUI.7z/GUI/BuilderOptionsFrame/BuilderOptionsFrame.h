#ifndef ROZE_STEALER_BUILDER_OPTIONS_FRAME_H
#define ROZE_STEALER_BUILDER_OPTIONS_FRAME_H

#include <QFrame>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QMessageBox>
#include <QFileDialog>
#include <QThread>
#include <QImage>
#include <QBuffer>
#include <QGridLayout>
#include <QLabel>
#include <QFont>

#include "../../Core/Settings.h"
#include "../../Utils/Utility.h"

namespace RozeStealer {

class BuilderOptionsFrame : public QFrame {
    Q_OBJECT

public:
    explicit BuilderOptionsFrame(QWidget* parent = nullptr);

    // Data members to hold current settings
    Settings currentSettings;

private slots:
    void testC2ButtonControl_Callback();
    void C2ModeButtonControl_Callback();
    void bindExeButtonControl_Callback();
    void selectIconButtonControl_Callback();
    void buildModeButtonControl_Callback();
    void consoleModeButtonControl_Callback();
    void buildButtonControl_Callback();
    void fakeError_Event();
    void pumpStub_Event();

private:
    // GUI Elements
    QLineEdit* c2EntryControl;
    QPushButton* testC2ButtonControl;

    QCheckBox* pingMeCheckboxControl;
    QCheckBox* vmProtectCheckboxControl;
    QCheckBox* startupCheckboxControl;
    QCheckBox* meltCheckboxControl;
    QCheckBox* pumpStubCheckboxControl;

    QCheckBox* captureWebcamCheckboxControl;
    QCheckBox* capturePasswordsCheckboxControl;
    QCheckBox* captureCookiesCheckboxControl;
    QCheckBox* captureHistoryCheckboxControl;
    QCheckBox* captureAutofillsCheckboxControl;
    QCheckBox* captureDiscordTokensCheckboxControl;
    QCheckBox* captureGamesCheckboxControl;
    QCheckBox* captureWalletsCheckboxControl;
    QCheckBox* captureWifiPasswordsCheckboxControl;
    QCheckBox* captureSysteminfoCheckboxControl;
    QCheckBox* captureScreenshotCheckboxControl;
    QCheckBox* captureTelegramChecboxControl;
    QCheckBox* captureCommonFilesChecboxControl;

    QCheckBox* fakeErrorCheckboxControl;
    QCheckBox* blockAvSitesCheckboxControl;
    QCheckBox* discordInjectionCheckboxControl;
    QCheckBox* uacBypassCheckboxControl;

    QPushButton* C2ModeButtonControl;
    QPushButton* bindExeButtonControl;
    QPushButton* selectIconButtonControl;
    QPushButton* buildModeButtonControl;
    QPushButton* consoleModeButtonControl;
    QPushButton* buildButtonControl;

    QFont font;
    QGridLayout* layout;

    void setupUi();
    void updateC2ModeButtonText();
    void updateBuildModeButtonText();
    void updateConsoleModeButtonText();
    void updateBindExeButtonText();
    void updateSelectIconButtonText();

    // Helper for testC2ButtonControl_Callback
    void performC2Test();

signals:
    void buildExecutable(const QString& configData, const QByteArray& iconBytes, const QString& boundFilePath);
    void buildPythonFile(const QString& configData);
};

} // namespace RozeStealer

#endif // ROZE_STEALER_BUILDER_OPTIONS_FRAME_H

