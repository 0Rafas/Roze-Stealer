
#include "FakeErrorBuilder.h"
#include <QProcess>

namespace RozeStealer {

FakeErrorBuilder::FakeErrorBuilder(QWidget* parent) : QDialog(parent), iconValue(0) {
    setWindowTitle("Roze Stealer [Fake Error Builder]");
    setFixedSize(833, 563);
    setModal(true);
    
    setupUi();
}

void FakeErrorBuilder::setupUi() {
    // Create font
    font = QFont();
    font.setPointSize(12);
    
    // Create layout
    layout = new QGridLayout(this);
    setLayout(layout);
    
    // Create title entry
    titleEntry = new QLineEdit(this);
    titleEntry->setPlaceholderText("Enter title here");
    titleEntry->setMinimumHeight(35);
    titleEntry->setFont(font);
    layout->addWidget(titleEntry, 0, 1, 1, 2);
    
    // Create message entry
    messageEntry = new QLineEdit(this);
    messageEntry->setPlaceholderText("Enter message here");
    messageEntry->setMinimumHeight(35);
    messageEntry->setFont(font);
    layout->addWidget(messageEntry, 1, 1, 1, 2);
    
    // Create icon radio buttons
    iconGroup = new QButtonGroup(this);
    
    iconChoiceSt = new QRadioButton("Stop", this);
    iconChoiceSt->setFont(font);
    iconChoiceSt->setChecked(true); // Default selection
    iconGroup->addButton(iconChoiceSt, 0);
    layout->addWidget(iconChoiceSt, 4, 1, 1, 1, Qt::AlignLeft);
    
    iconChoiceQn = new QRadioButton("Question", this);
    iconChoiceQn->setFont(font);
    iconGroup->addButton(iconChoiceQn, 16);
    layout->addWidget(iconChoiceQn, 5, 1, 1, 1, Qt::AlignLeft);
    
    iconChoiceWa = new QRadioButton("Warning", this);
    iconChoiceWa->setFont(font);
    iconGroup->addButton(iconChoiceWa, 32);
    layout->addWidget(iconChoiceWa, 6, 1, 1, 1, Qt::AlignLeft);
    
    iconChoiceIn = new QRadioButton("Information", this);
    iconChoiceIn->setFont(font);
    iconGroup->addButton(iconChoiceIn, 48);
    layout->addWidget(iconChoiceIn, 7, 1, 1, 1, Qt::AlignLeft);
    
    connect(iconGroup, QOverload<int>::of(&QButtonGroup::buttonClicked), this, &FakeErrorBuilder::onIconSelected);
    
    // Create test button
    testButton = new QPushButton("Test", this);
    testButton->setMinimumHeight(28);
    testButton->setFont(font);
    testButton->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(testButton, &QPushButton::clicked, this, &FakeErrorBuilder::testFakeError);
    layout->addWidget(testButton, 4, 2, 1, 1);
    
    // Create save button
    saveButton = new QPushButton("Save", this);
    saveButton->setMinimumHeight(28);
    saveButton->setFont(font);
    saveButton->setStyleSheet("background-color: #393646; color: white; hover { background-color: #6D5D6E; }");
    connect(saveButton, &QPushButton::clicked, this, &FakeErrorBuilder::saveFakeError);
    layout->addWidget(saveButton, 5, 2, 1, 1);
    
    // Set layout spacing and margins
    layout->setSpacing(10);
    layout->setContentsMargins(20, 20, 20, 20);
    
    // Set row and column stretches
    for (int i = 0; i < 9; ++i) {
        layout->setRowStretch(i, (i == 8) ? 2 : 1);
    }
    layout->setColumnStretch(1, 1);
}

void FakeErrorBuilder::onIconSelected(int icon) {
    iconValue = icon;
}

void FakeErrorBuilder::testFakeError() {
    QString title = titleEntry->text();
    QString message = messageEntry->text();
    
    if (title.isEmpty()) {
        title = "Title";
        titleEntry->setText(title);
    }
    
    if (message.isEmpty()) {
        message = "Message";
        messageEntry->setText(message);
    }
    
    // In Windows, this would use mshta to show a message box
    // For now, we'll use QMessageBox as a simulation
    QMessageBox msgBox;
    msgBox.setWindowTitle(title);
    msgBox.setText(message);
    
    switch (iconValue) {
        case 0:
            msgBox.setIcon(QMessageBox::Critical);
            break;
        case 16:
            msgBox.setIcon(QMessageBox::Question);
            break;
        case 32:
            msgBox.setIcon(QMessageBox::Warning);
            break;
        case 48:
            msgBox.setIcon(QMessageBox::Information);
            break;
    }
    
    msgBox.exec();
}

void FakeErrorBuilder::saveFakeError() {
    QString title = titleEntry->text();
    QString message = messageEntry->text();
    
    if (title.isEmpty() && message.isEmpty()) {
        reject(); // Cancel without saving
        return;
    }
    
    if (title.isEmpty()) {
        QMessageBox::critical(this, "Error", "Title cannot be empty");
        return;
    }
    
    if (message.isEmpty()) {
        QMessageBox::critical(this, "Error", "Message cannot be empty");
        return;
    }
    
    accept(); // Save and close
}

} // namespace RozeStealer

