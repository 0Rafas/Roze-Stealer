#ifndef ROZE_STEALER_PUMPER_SETTINGS_H
#define ROZE_STEALER_PUMPER_SETTINGS_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>
#include <QGridLayout>
#include <QFont>

namespace RozeStealer {

class PumperSettings : public QDialog {
    Q_OBJECT

public:
    explicit PumperSettings(QWidget* parent = nullptr);
    long long getLimit() const { return limit; }

private slots:
    void ok_Event();
    void on_limit_change(const QString& text);

private:
    QLineEdit* limitEntry;
    QPushButton* okButton;
    QLabel* noteLabel;
    QFont font;
    QGridLayout* layout;
    long long limit;

    void setupUi();
};

} // namespace RozeStealer

#endif // ROZE_STEALER_PUMPER_SETTINGS_H

