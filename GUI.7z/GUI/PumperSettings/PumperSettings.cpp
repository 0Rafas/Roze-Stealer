
#include "PumperSettings.h"

namespace RozeStealer {

PumperSettings::PumperSettings(QWidget* parent) : QDialog(parent), limit(0) {
    setWindowTitle("Roze Stealer [File Pumper]");
    setFixedSize(500, 200);
    setModal(true);
    
    setupUi();
}

void PumperSettings::setupUi() {
    // Create font
    font = QFont();
    font.setPointSize(10);
    
    // Create layout
    layout = new QGridLayout(this);
    setLayout(layout);
    
    // Create note label
    noteLabel = new QLabel("Please specify the pumped output file size (in MB).\nNote: If the size of the stub is already greater than the\nprovided size, nothing happens.", this);
    noteLabel->setFont(font);
    layout->addWidget(noteLabel, 0, 0, 1, 3, Qt::AlignCenter);
    
    // Create limit entry
    limitEntry = new QLineEdit(this);
    limitEntry->setText(QString::number(limit));
    limitEntry->setStyleSheet("color: white;");
    limitEntry->setFont(font);
    connect(limitEntry, &QLineEdit::textChanged, this, &PumperSettings::on_limit_change);
    layout->addWidget(limitEntry, 1, 1, 1, 1);
    
    // Create OK button
    okButton = new QPushButton("OK", this);
    okButton->setFont(font);
    okButton->setStyleSheet("background-color: green; color: white; hover { background-color: lightgreen; }");
    connect(okButton, &QPushButton::clicked, this, &PumperSettings::ok_Event);
    layout->addWidget(okButton, 2, 1, 1, 1);
    
    // Set layout spacing and margins
    layout->setSpacing(10);
    layout->setContentsMargins(10, 10, 10, 10);
}

void PumperSettings::ok_Event() {
    bool ok;
    long long value = limitEntry->text().toLongLong(&ok);
    
    if (ok && value >= 0) {
        limit = value;
        accept();
    } else {
        QMessageBox::critical(this, "Error", "The size should be a positive number!");
    }
}

void PumperSettings::on_limit_change(const QString& text) {
    bool ok;
    text.toLongLong(&ok);
    
    if (ok) {
        okButton->setEnabled(true);
        okButton->setStyleSheet("background-color: green; color: white; hover { background-color: lightgreen; }");
    } else {
        okButton->setEnabled(false);
        okButton->setStyleSheet("background-color: red; color: white;");
    }
}

} // namespace RozeStealer

