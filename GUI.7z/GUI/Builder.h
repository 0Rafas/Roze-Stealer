#ifndef ROZE_STEALER_BUILDER_H
#define ROZE_STEALER_BUILDER_H

#include <QMainWindow>
#include <QLabel>
#include <QMessageBox>
#include <QProcess>
#include <QFile>
#include <QDir>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QVBoxLayout>
#include <QFont>

#include "BuilderOptionsFrame/BuilderOptionsFrame.h"
#include "../Core/Settings.h"
#include "../Utils/Utility.h"

namespace RozeStealer {

class Builder : public QMainWindow {
    Q_OBJECT

public:
    explicit Builder(QWidget* parent = nullptr);
    ~Builder();

private slots:
    void handleBuildExecutable(const QString& configData, const QByteArray& iconBytes, const QString& boundFilePath);
    void handleBuildPythonFile(const QString& configData);

private:
    QLabel* titleLabel;
    BuilderOptionsFrame* builderOptions;
    QWidget* centralWidget;
    QVBoxLayout* mainLayout;

    void setupUi();
    void checkPythonEnvironment();
    void runBuildProcess(const QStringList& args);
};

} // namespace RozeStealer

#endif // ROZE_STEALER_BUILDER_H

