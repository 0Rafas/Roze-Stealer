#ifndef ROZE_STEALER_ERRORS_H
#define ROZE_STEALER_ERRORS_H

#include <string>
#include <vector>

namespace RozeStealer {

class Errors {
public:
    static std::vector<std::string> errors;
    static void catchException(const std::string& errorMessage);
};

} // namespace RozeStealer

#endif // ROZE_STEALER_ERRORS_H


