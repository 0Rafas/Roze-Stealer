#ifndef ROZE_STEALER_PROCESS_H
#define ROZE_STEALER_PROCESS_H

#include <string>
#include <vector>
#include <map>
#include <utility>

#include "../Core/Settings.h"

namespace RozeStealer {

class Process {
public:
    static std::string writeSettings(const std::string& code, const Settings& settings, const std::string& injectionCode);
    static void prepareEnvironment(const Settings& settings);
    static std::pair<Settings, std::string> readSettings();
    static std::string encryptString(const std::string& plainText);
    static void junk(const std::string& path);
    static void makeVersionFileAndCert();
    static void mainProcess();
};

} // namespace RozeStealer

#endif // ROZE_STEALER_PROCESS_H


