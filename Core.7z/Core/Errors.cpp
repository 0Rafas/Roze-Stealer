
#include "Errors.h"
#include <iostream>

namespace RozeStealer {

std::vector<std::string> Errors::errors;

void Errors::catchException(const std::string& errorMessage) {
    errors.push_back(errorMessage);
    // In a real application, you might also log this to a file or display it to the user.
    std::cerr << "Error caught: " << errorMessage << std::endl;
}

} // namespace RozeStealer


