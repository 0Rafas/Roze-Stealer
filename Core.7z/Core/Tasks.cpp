
#include "Tasks.h"

namespace RozeStealer {

std::vector<std::thread> Tasks::threads;

void Tasks::addTask(std::thread&& task) {
    threads.push_back(std::move(task));
}

void Tasks::waitForAll() {
    for (std::thread& thread : threads) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    threads.clear(); // Clear the vector after joining all threads
}

} // namespace RozeStealer


